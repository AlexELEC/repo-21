# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2011-present Alex@ELEC (https://alexelec.github.io)

import os, sys
import xbmc
import xbmcaddon
import requests
import json
import pyxbmct.addonwindow as pyxbmct
from urllib.request import Request, urlopen

__author__ = 'AlexELEC'
__scriptid__ = 'script.tvlink.conrol'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')
_check_icon = os.path.join(__cwd__, 'check.png')

ip = __addon__.getSetting('tvlinkIP')
if ip == '':
    ip = xbmc.getIPAddress()
port = __addon__.getSetting('tvlinkPort')
if port == '': port = '2020'

# No longer needed after initialization. Keep the xbmcaddon.Addon SWIG
# wrapper from surviving until Python interpreter teardown.
del __addon__

INFO_DLG = False

def notify(message):
    xbmc.executebuiltin('Notification("TVLINK", "%s", 3000, "%s/icon.png")' % (message, __cwd__))

class TvlinkAddon(pyxbmct.AddonDialogWindow):
    def __init__(self, title="", items=None):
        super(TvlinkAddon, self).__init__(title)
        self.setGeometry(800, 340, 8, 7)
        self.selected = {}
        self.data = items
        self.set_controls()
        self.connect_controls()
        index = 0
        #info_list: [0-disabled, 1-srcName, 2-chName, 3-url, 4-play_indx]
        for ch in items:
            disabled_link, src_name, real_chName, src_link, play_indx = ch
            short_src = src_name.replace("m3u_", '')
            short_lnk = src_link.replace(f"ext:{src_name}:", '')
            if "?" in short_lnk:
                short_lnk = short_lnk.split('?')[0]
            if int(play_indx) == 1:
                strName = f'[COLOR orange]{short_src}: {short_lnk}[/COLOR]'
            else:
                strName = f'{short_src}: {short_lnk}'
            self.listing.addItem(strName)
            if int(disabled_link) == 1:
                self.listing.getListItem(index).setLabel2("unchecked")
                self.listing.getListItem(index).setArt({'icon': ""})
            else:
                self.listing.getListItem(index).setLabel2("checked")
                self.listing.getListItem(index).setArt({'icon': _check_icon})
            index += 1
        self.set_navigation()

    def set_controls(self):
        self.listing = pyxbmct.List(_imageWidth=15)
        self.placeControl(self.listing, 0, 0, rowspan=7, columnspan=7)
        self.ok_button = pyxbmct.Button("OK")
        self.placeControl(self.ok_button, 7, 0)
        self.next_button = pyxbmct.Button("Next")
        self.placeControl(self.next_button, 7, 2)
        self.upd_button = pyxbmct.Button("Update")
        self.placeControl(self.upd_button, 7, 3)
        self.info_button = pyxbmct.Button("Info")
        self.placeControl(self.info_button, 7, 4)
        self.cancel_button = pyxbmct.Button("Cancel")
        self.placeControl(self.cancel_button, 7, 6)

    def connect_controls(self):
        self.connect(self.listing, self.check_uncheck)
        self.connect(self.ok_button, self.ok)
        self.connect(self.next_button, self.next_stream)
        self.connect(self.upd_button, self.upd_sources)
        self.connect(self.info_button, self.info_streams)
        self.connect(self.cancel_button, self.close)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(pyxbmct.ACTION_PREVIOUS_MENU, self.close)

    def set_navigation(self):
        self.listing.controlLeft(self.ok_button)
        self.listing.controlRight(self.cancel_button)
        self.ok_button.setNavigation(self.listing, self.listing, self.cancel_button, self.next_button)
        self.next_button.setNavigation(self.listing, self.listing, self.ok_button, self.upd_button)
        self.upd_button.setNavigation(self.listing, self.listing, self.next_button, self.info_button)
        self.info_button.setNavigation(self.listing, self.listing, self.upd_button, self.cancel_button)
        self.cancel_button.setNavigation(self.listing, self.listing, self.info_button, self.ok_button)
        if self.listing.size():
            self.setFocus(self.listing)
        else:
            self.setFocus(self.cancel_button)

    def _cleanup(self):
        # pyxbmct stores controls together with bound methods in these lists.
        # Clear them explicitly to break the self -> callback -> self cycle
        # before the SWIG WindowDialog/control wrappers are destroyed.
        self.actions_connected.clear()
        self.controls_connected.clear()

    def check_uncheck(self):
        list_item = self.listing.getSelectedItem()
        if list_item.getLabel2() == "checked":
            list_item.setArt({'icon': ""})
            list_item.setLabel2("unchecked")
        else:
            list_item.setArt({'icon': _check_icon})
            list_item.setLabel2("checked")

    def ok(self):
        index = 0
        for ch in self.data:
            if self.listing.getListItem(index).getLabel2() == "checked":
                disabled = 0
            else:
                disabled = 1
            self.selected[ch[3]] = disabled
            index += 1
        self._cleanup()
        super(TvlinkAddon, self).close()

    def next_stream(self):
        chID = requests.get(f"http://{ip}:{port}/clientplay/getID")
        if chID:
            if not chID.text == "":
                proxyPort = int(port) + 1
                sendNext = requests.get(f"http://{ip}:{proxyPort}/{chID.text}/next")
                if sendNext.status_code == 200:
                    notify(f"Send next stream for Channel ID: {chID.text}")
                else:
                    notify(f"Error: response status {sendNext.status_code}")
            else:
                notify(f"Error send command: Channel ID not foumd!")
        self._cleanup()
        super(TvlinkAddon, self).close()

    def upd_sources(self):
        notify("Start update sources now...")
        sendUpd = requests.get(f"http://{ip}:{port}/updsrc")
        if sendUpd.status_code == 200:
            notify("Update sources Done!")
        else:
            notify(f"Error: update sources {sendUpd.status_code}")
        self._cleanup()
        super(TvlinkAddon, self).close()

    def close(self):
        self.selected = {}
        self.data = []
        self._cleanup()
        super(TvlinkAddon, self).close()

    def info_streams(self):
        global INFO_DLG
        INFO_DLG = True
        self.close()

class TvlinkInfo(pyxbmct.AddonDialogWindow):
    def __init__(self, title="Current streams", items=None):
        super(TvlinkInfo, self).__init__(title)
        self.setGeometry(800, 340, 8, 5)
        self.set_controls()
        self.connect_controls()
        # STATUS_STREAMS {user_ip: [chID, srcName, chTitle, lnk, startTime, orgURL]}
        for client in items.keys():
            chID, chSource, chTitle, chLink, chStart, chOrgUrl = items.get(client)
            chSource = chSource.replace("m3u_", "")
            if "?" in chOrgUrl: chOrgUrl = chOrgUrl.split('?')[0]
            ip = client.split(':')[0]
            strStream = f'{chStart} [COLOR orange]{ip}[/COLOR]:  {chTitle} [COLOR orange]{chSource}[/COLOR] {chOrgUrl}'
            self.listing.addItem(strStream)
        self.set_navigation()

    def set_controls(self):
        self.listing = pyxbmct.List(_imageWidth=15)
        self.placeControl(self.listing, 0, 0, rowspan=7, columnspan=5)
        self.ok_button = pyxbmct.Button("OK")
        self.placeControl(self.ok_button, 7, 2)

    def connect_controls(self):
        self.connect(self.ok_button, self.ok)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.ok)
        self.connect(pyxbmct.ACTION_PREVIOUS_MENU, self.ok)

    def set_navigation(self):
        self.listing.controlLeft(self.ok_button)
        self.listing.controlRight(self.ok_button)
        self.ok_button.setNavigation(self.listing, self.listing, self.listing, self.listing)
        self.setFocus(self.ok_button)

    def _cleanup(self):
        self.actions_connected.clear()
        self.controls_connected.clear()

    def ok(self):
        self._cleanup()
        super(TvlinkInfo, self).close()

def main():
    req = Request(f"http://{ip}:{port}/clientplay")
    try:
        with urlopen(req) as context:
            ret_srv = context.read()
        ret_srv = ret_srv.decode('utf-8')
    except:
        notify("no connection to server!")
        return

    try:
        # chData {chTitle: ( [disabled, srcName, chName, url, play_indx], ...) }
        chData = json.loads(ret_srv)
        chData = list(chData.items())
        chTitle, chList = chData[0]
    except:
        notify("no channel data!")
        return

    dialog = TvlinkAddon(chTitle, chList)
    try:
        dialog.doModal()
        url = f"http://{ip}:{port}/setlives"
        html = requests.post(url, data=json.dumps(dialog.selected))
    finally:
        dialog._cleanup()
        del dialog

    if not INFO_DLG: return
    req = Request(f"http://{ip}:{port}/clientinfo")
    try:
        with urlopen(req) as context:
            ret_srv = context.read()
        ret_srv = ret_srv.decode('utf-8')
    except:
        notify("no connection to server!")
        return

    try:
        chData = json.loads(ret_srv)
    except:
        notify("no streams data!")
        return

    TITLE = "Current streams"
    req = Request(f"http://{ip}:{port}/ret-sys")
    try:
        with urlopen(req) as context:
            ret_srv = context.read()
        ret_srv = ret_srv.decode('utf-8')
        RAM, SOC  = ret_srv.split(',')
        TITLE = f"Current streams | Use RAM (mb): {RAM} | Use Sockets: {SOC}"
    except: pass

    dialog = TvlinkInfo(TITLE, chData)
    try:
        dialog.doModal()
    finally:
        dialog._cleanup()
        del dialog

if (__name__ == '__main__'):
    main()
